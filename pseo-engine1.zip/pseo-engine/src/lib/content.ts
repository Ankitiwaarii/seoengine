/**
 * Turns data into copy. Every sentence here is computed from the listings,
 * so each page says something specific and true about its city — the thing
 * that separates useful programmatic pages from spun, thin ones.
 */
import type { PageData } from "./data";
import { CURRENCY, PRICE_UNIT } from "./config";

const fmt = (n: number) => CURRENCY + Math.round(n).toLocaleString("en-IN");
const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};

export function buildStats(p: PageData) {
  const prices = p.listings.map((l) => l.priceFrom).filter((x): x is number => x != null);
  const rated = p.listings.filter((l) => l.rating != null);
  const amenityCounts = new Map<string, number>();
  p.listings.forEach((l) => l.amenities.forEach((a) => amenityCounts.set(a, (amenityCounts.get(a) ?? 0) + 1)));
  const topAmenities = [...amenityCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)
    .map(([name, c]) => ({ name, pct: Math.round((c / p.listings.length) * 100) }));
  return {
    count: p.listings.length,
    minPrice: prices.length ? Math.min(...prices) : null,
    maxPrice: prices.length ? Math.max(...prices) : null,
    medianPrice: prices.length ? median(prices) : null,
    avgRating: rated.length ? rated.reduce((s, l) => s + l.rating!, 0) / rated.length : null,
    totalReviews: p.listings.reduce((s, l) => s + l.reviewCount, 0),
    topAmenities,
    best: p.listings[0],
    cheapest: prices.length ? p.listings.reduce((a, b) => ((a.priceFrom ?? Infinity) <= (b.priceFrom ?? Infinity) ? a : b)) : null,
    unit: PRICE_UNIT[p.service.slug] ?? "",
  };
}
export type Stats = ReturnType<typeof buildStats>;

export function buildIntro(p: PageData, st: Stats, state: { avgPrice: number | null }) {
  const { service: s, location: l } = p;
  const parts: string[] = [];
  parts.push(`We compared ${st.count} ${s.plural.toLowerCase()} in ${l.name}, ${l.state}, using ${st.totalReviews.toLocaleString("en-IN")} reviews and published prices.`);
  if (st.medianPrice != null) {
    let line = `The typical price is ${fmt(st.medianPrice)}${st.unit}, with options from ${fmt(st.minPrice!)} to ${fmt(st.maxPrice!)}.`;
    if (state.avgPrice) {
      const diff = Math.round(((st.medianPrice - state.avgPrice) / state.avgPrice) * 100);
      if (Math.abs(diff) >= 5) line += ` That is about ${Math.abs(diff)}% ${diff > 0 ? "above" : "below"} the ${l.state} average.`;
      else line += ` That is in line with the ${l.state} average.`;
    }
    parts.push(line);
  }
  if (st.best) parts.push(`${st.best.name} ranks first on our review-weighted score (${st.best.rating}★ from ${st.best.reviewCount} reviews).`);
  if (st.topAmenities[0]) parts.push(`${st.topAmenities[0].name} is the most common amenity, offered by ${st.topAmenities[0].pct}% of places.`);
  return parts.join(" ");
}

export function buildFaqs(p: PageData, st: Stats) {
  const { service: s, location: l } = p;
  const faqs: { q: string; a: string }[] = [];
  if (st.medianPrice != null)
    faqs.push({ q: `How much does a ${s.name.toLowerCase()} cost in ${l.name}?`, a: `Prices in ${l.name} start at ${fmt(st.minPrice!)}${st.unit}. The median across ${st.count} places we track is ${fmt(st.medianPrice)}${st.unit}.` });
  if (st.best)
    faqs.push({ q: `What is the best-rated ${s.name.toLowerCase()} in ${l.name}?`, a: `${st.best.name} currently ranks highest, rated ${st.best.rating}/5 across ${st.best.reviewCount} reviews. Rankings weight ratings by review volume.` });
  if (st.cheapest && st.cheapest.id !== st.best?.id)
    faqs.push({ q: `What is the cheapest ${s.name.toLowerCase()} in ${l.name}?`, a: `${st.cheapest.name} has the lowest listed price at ${fmt(st.cheapest.priceFrom!)}${st.unit}.` });
  faqs.push({ q: `How many ${s.plural.toLowerCase()} are there in ${l.name}?`, a: `We currently list ${st.count} ${s.plural.toLowerCase()} in ${l.name}. The list is refreshed from our data source regularly.` });
  return [...(p.override?.faqs ?? []), ...faqs];
}

export const money = fmt;
