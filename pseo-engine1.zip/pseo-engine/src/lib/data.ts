import { cache } from "react";
import { and, avg, count, eq, max } from "drizzle-orm";
import { db, listings, locations, pageOverrides, services } from "@/db";
import { MIN_LISTINGS } from "./config";

/** Every service × location combo that has listings. The source of truth for which pages exist. */
export const getCombos = cache(async () => {
  const [groups, svc, locs, ovr] = await Promise.all([
    db.select({ serviceId: listings.serviceId, locationId: listings.locationId, n: count(), lastmod: max(listings.updatedAt) })
      .from(listings).groupBy(listings.serviceId, listings.locationId),
    db.select().from(services),
    db.select().from(locations),
    db.select({ serviceId: pageOverrides.serviceId, locationId: pageOverrides.locationId }).from(pageOverrides).where(eq(pageOverrides.noindex, true)),
  ]);
  const sMap = new Map(svc.map((s) => [s.id, s]));
  const lMap = new Map(locs.map((l) => [l.id, l]));
  const forced = new Set(ovr.map((o) => `${o.serviceId}:${o.locationId}`));
  return groups
    .map((g) => ({
      service: sMap.get(g.serviceId)!,
      location: lMap.get(g.locationId)!,
      count: g.n,
      lastmod: g.lastmod ? new Date(g.lastmod) : undefined,
      indexable: g.n >= MIN_LISTINGS && !forced.has(`${g.serviceId}:${g.locationId}`),
    }))
    .sort((a, b) => b.location.population - a.location.population);
});

export const getServices = cache(async () => db.select().from(services).orderBy(services.id));
export const getService = cache(async (slug: string) => (await db.select().from(services).where(eq(services.slug, slug)))[0] ?? null);
export const getLocation = cache(async (slug: string) => (await db.select().from(locations).where(eq(locations.slug, slug)))[0] ?? null);

export const getPage = cache(async (serviceSlug: string, citySlug: string) => {
  const [service, location] = await Promise.all([getService(serviceSlug), getLocation(citySlug)]);
  if (!service || !location) return null;
  const combo = and(eq(listings.serviceId, service.id), eq(listings.locationId, location.id));
  const [raw, [override]] = await Promise.all([
    db.select().from(listings).where(combo),
    db.select().from(pageOverrides).where(and(eq(pageOverrides.serviceId, service.id), eq(pageOverrides.locationId, location.id))),
  ]);
  if (raw.length === 0) return null;
  const ranked = raw
    // Review-weighted score so a 5.0 with 3 reviews doesn't beat a 4.7 with 600
    .map((l) => ({ ...l, score: ((l.rating ?? 0) * l.reviewCount + 4.2 * 20) / (l.reviewCount + 20) }))
    .sort((a, b) => b.score - a.score);
  return { service, location, listings: ranked, override: override ?? null };
});
export type PageData = NonNullable<Awaited<ReturnType<typeof getPage>>>;

/** Same service in the closest cities that have pages — the main internal-link block. */
export async function getNearby(serviceId: number, loc: { id: number; lat: number; lng: number }, limit = 6) {
  return (await getCombos())
    .filter((c) => c.service.id === serviceId && c.location.id !== loc.id && c.indexable)
    .map((c) => ({ ...c, km: haversine(loc.lat, loc.lng, c.location.lat, c.location.lng) }))
    .sort((a, b) => a.km - b.km)
    .slice(0, limit);
}

/** Other services available in the same city. */
export async function getSiblings(locationId: number, serviceId: number) {
  return (await getCombos()).filter((c) => c.location.id === locationId && c.service.id !== serviceId && c.indexable);
}

/** State-wide averages, so a city page can say how it compares. */
export async function getStateStats(serviceId: number, stateSlug: string) {
  const [r] = await db
    .select({ avgPrice: avg(listings.priceFrom), avgRating: avg(listings.rating) })
    .from(listings).innerJoin(locations, eq(listings.locationId, locations.id))
    .where(and(eq(listings.serviceId, serviceId), eq(locations.stateSlug, stateSlug)));
  return { avgPrice: r?.avgPrice ? Number(r.avgPrice) : null, avgRating: r?.avgRating ? Number(r.avgRating) : null };
}

function haversine(lat1: number, lon1: number, lat2: number, lon2: number) {
  const r = (d: number) => (d * Math.PI) / 180;
  const a = Math.sin(r(lat2 - lat1) / 2) ** 2 + Math.cos(r(lat1)) * Math.cos(r(lat2)) * Math.sin(r(lon2 - lon1) / 2) ** 2;
  return Math.round(6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}
