import type { Metadata } from "next";
import { SITE_NAME, SITE_URL, YEAR } from "./config";
import type { PageData } from "./data";
import type { Stats } from "./content";

export const url = (path: string) => `${SITE_URL}${path}`;

export function pageMeta(p: PageData, st: Stats, indexable: boolean): Metadata {
  const { service: s, location: l } = p;
  const path = `/${s.slug}/${l.slug}`;
  const title = `${st.count} Best ${s.plural} in ${l.name} (${YEAR}) – Prices & Reviews`;
  const price = st.minPrice != null ? ` from ₹${st.minPrice.toLocaleString("en-IN")}${st.unit}` : "";
  const description = `Compare ${st.count} ${s.plural.toLowerCase()} in ${l.name}, ${l.state}${price}. Ranked by ${st.totalReviews.toLocaleString("en-IN")} reviews, with amenities and prices side by side.`;
  return {
    title, description,
    alternates: { canonical: url(path) },
    robots: indexable ? { index: true, follow: true } : { index: false, follow: true },
    openGraph: { title, description, url: url(path), siteName: SITE_NAME, type: "website" },
  };
}

export function pageJsonLd(p: PageData, faqs: { q: string; a: string }[]) {
  const { service: s, location: l } = p;
  const path = `/${s.slug}/${l.slug}`;
  return [
    {
      "@context": "https://schema.org", "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: url("/") },
        { "@type": "ListItem", position: 2, name: s.plural, item: url(`/${s.slug}`) },
        { "@type": "ListItem", position: 3, name: l.name, item: url(path) },
      ],
    },
    {
      "@context": "https://schema.org", "@type": "ItemList",
      name: `${s.plural} in ${l.name}`,
      itemListElement: p.listings.slice(0, 20).map((x, i) => ({
        "@type": "ListItem", position: i + 1,
        item: {
          "@type": "LocalBusiness", name: x.name,
          address: { "@type": "PostalAddress", streetAddress: x.address, addressLocality: l.name, addressRegion: l.state, addressCountry: "IN" },
          ...(x.url ? { url: x.url } : {}),
          // Only mark up ratings you actually display on the page, from a real source.
          ...(x.rating != null && x.reviewCount > 0 ? { aggregateRating: { "@type": "AggregateRating", ratingValue: x.rating, reviewCount: x.reviewCount } } : {}),
        },
      })),
    },
    {
      "@context": "https://schema.org", "@type": "FAQPage",
      mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a } })),
    },
  ];
}

export function JsonLd({ data }: { data: unknown }) {
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(data).replace(/</g, "\\u003c") }} />;
}
