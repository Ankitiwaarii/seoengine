export const SITE_URL = (process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000").replace(/\/$/, "");
export const SITE_NAME = process.env.NEXT_PUBLIC_SITE_NAME ?? "WorkspaceFinder";
export const MIN_LISTINGS = Number(process.env.MIN_LISTINGS_TO_INDEX ?? 3);
export const PRERENDER_LIMIT = Number(process.env.PRERENDER_LIMIT ?? 500);
export const YEAR = new Date().getFullYear();
export const CURRENCY = "₹";
/** Unit label per service, used in price copy. Unknown services fall back to "". */
export const PRICE_UNIT: Record<string, string> = {
  "coworking-spaces": "/desk/month",
  "meeting-rooms": "/hour",
  "virtual-offices": "/month",
};
