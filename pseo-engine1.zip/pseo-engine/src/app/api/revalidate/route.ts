import { revalidatePath } from "next/cache";
import { NextRequest, NextResponse } from "next/server";

/** POST /api/revalidate?secret=...&path=/coworking-spaces/pune  (omit path to refresh everything) */
export async function POST(req: NextRequest) {
  const secret = req.nextUrl.searchParams.get("secret");
  if (!process.env.REVALIDATE_SECRET || secret !== process.env.REVALIDATE_SECRET)
    return NextResponse.json({ ok: false }, { status: 401 });
  const path = req.nextUrl.searchParams.get("path");
  if (path) revalidatePath(path);
  else revalidatePath("/", "layout");
  return NextResponse.json({ ok: true, revalidated: path ?? "all" });
}
