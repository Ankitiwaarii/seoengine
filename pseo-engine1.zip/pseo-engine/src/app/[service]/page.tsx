import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCombos, getService, getServices } from "@/lib/data";
import { url } from "@/lib/seo";

type Params = { params: Promise<{ service: string }> };
export const revalidate = 86400;

export async function generateStaticParams() {
  return (await getServices()).map((s) => ({ service: s.slug }));
}

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const s = await getService((await params).service);
  if (!s) return {};
  return {
    title: `${s.plural} in India – Compare by City`,
    description: `Browse ${s.plural.toLowerCase()} across Indian cities. ${s.description}`,
    alternates: { canonical: url(`/${s.slug}`) },
  };
}

/** Hub page: links every indexable city page, grouped by state. Keeps all pages ≤2 clicks from home. */
export default async function Hub({ params }: Params) {
  const s = await getService((await params).service);
  if (!s) notFound();
  const combos = (await getCombos()).filter((c) => c.service.id === s.id && c.indexable);
  const byState = new Map<string, typeof combos>();
  combos.forEach((c) => byState.set(c.location.state, [...(byState.get(c.location.state) ?? []), c]));
  return (
    <>
      <nav className="crumbs"><Link href="/">Home</Link> › {s.plural}</nav>
      <h1>{s.plural} in India</h1>
      <p className="lede">{s.description} Compare {combos.reduce((n, c) => n + c.count, 0)} places across {combos.length} cities.</p>
      {[...byState.entries()].sort().map(([state, cs]) => (
        <section key={state}>
          <h2>{state}</h2>
          <ul className="links">
            {cs.map((c) => (<li key={c.location.id}><Link href={`/${s.slug}/${c.location.slug}`}>{s.plural} in {c.location.name}</Link><small>{c.count} places</small></li>))}
          </ul>
        </section>
      ))}
    </>
  );
}
