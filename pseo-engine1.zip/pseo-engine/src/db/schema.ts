/**
 * Data model (MySQL / MariaDB — what Hostinger and most shared hosts provide).
 * Pure-JS driver (mysql2), so nothing has to compile on the server.
 * The matching CREATE TABLE statements live in scripts/migrate.ts; keep them in sync.
 */
import { mysqlTable, varchar, text, int, double, boolean, timestamp, index, uniqueIndex, customType } from "drizzle-orm/mysql-core";

// MariaDB stores JSON as LONGTEXT and hands it back as a string; MySQL parses it. Handle both.
const json = <T,>(name: string) =>
  customType<{ data: T; driverData: string }>({
    dataType: () => "json",
    toDriver: (v) => JSON.stringify(v),
    fromDriver: (v) => (typeof v === "string" ? JSON.parse(v) : v) as T,
  })(name);

/** What people search for: "coworking spaces", "dentists", "plumbers"... */
export const services = mysqlTable("services", {
  id: int("id").primaryKey().autoincrement(),
  slug: varchar("slug", { length: 191 }).notNull().unique(),
  name: varchar("name", { length: 191 }).notNull(),     // singular: "Coworking Space"
  plural: varchar("plural", { length: 191 }).notNull(), // plural:   "Coworking Spaces"
  description: text("description").notNull(),
});

/** Where they search: one row per city. */
export const locations = mysqlTable("locations", {
  id: int("id").primaryKey().autoincrement(),
  slug: varchar("slug", { length: 191 }).notNull().unique(),
  name: varchar("name", { length: 191 }).notNull(),
  state: varchar("state", { length: 191 }).notNull(),
  stateSlug: varchar("state_slug", { length: 191 }).notNull(),
  country: varchar("country", { length: 191 }).notNull().default("India"),
  lat: double("lat").notNull(),
  lng: double("lng").notNull(),
  population: int("population").notNull().default(0),
}, (t) => [index("loc_state_idx").on(t.stateSlug)]);

/** The real data that makes each page unique and useful. */
export const listings = mysqlTable("listings", {
  id: int("id").primaryKey().autoincrement(),
  externalId: varchar("external_id", { length: 191 }).notNull().unique(), // id in the source API → idempotent syncs
  name: varchar("name", { length: 255 }).notNull(),
  address: varchar("address", { length: 500 }).notNull(),
  rating: double("rating"),
  reviewCount: int("review_count").notNull().default(0),
  priceFrom: int("price_from"),
  url: varchar("url", { length: 500 }),
  phone: varchar("phone", { length: 50 }),
  amenities: json<string[]>("amenities").notNull().$defaultFn(() => []),
  serviceId: int("service_id").notNull(),
  locationId: int("location_id").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
}, (t) => [index("listing_combo_idx").on(t.serviceId, t.locationId)]);

/** Optional hand-written layer for high-value pages: editorial intro, extra FAQs, manual noindex. */
export const pageOverrides = mysqlTable("page_overrides", {
  id: int("id").primaryKey().autoincrement(),
  serviceId: int("service_id").notNull(),
  locationId: int("location_id").notNull(),
  intro: text("intro"),
  faqs: json<{ q: string; a: string }[]>("faqs").notNull().$defaultFn(() => []),
  noindex: boolean("noindex").notNull().default(false),
}, (t) => [uniqueIndex("override_combo_idx").on(t.serviceId, t.locationId)]);

export type Service = typeof services.$inferSelect;
export type Location = typeof locations.$inferSelect;
export type Listing = typeof listings.$inferSelect;
