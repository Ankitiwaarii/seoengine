import mysql from "mysql2/promise";
import { drizzle } from "drizzle-orm/mysql2";
import * as schema from "./schema";

// DATABASE_URL="mysql://USER:PASSWORD@HOST:3306/DBNAME"
const g = globalThis as unknown as { pool?: mysql.Pool };
export const pool =
  g.pool ??
  mysql.createPool({
    uri: process.env.DATABASE_URL,
    connectionLimit: Number(process.env.DB_POOL_SIZE ?? 5), // shared hosts cap connections per user
    waitForConnections: true,
  });
if (process.env.NODE_ENV !== "production") g.pool = pool;

export const db = drizzle(pool, { schema, mode: "default" });
export * from "./schema";
