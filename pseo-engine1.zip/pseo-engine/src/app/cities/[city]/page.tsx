import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCombos, getLocation } from "@/lib/data";
import { url } from "@/lib/seo";

type Params = { params: Promise<{ city: string }> };
export const revalidate = 86400;
export const dynamicParams = true;

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const l = await getLocation((await params).city);
  if (!l) return {};
  return {
    title: `Workspaces in ${l.name}, ${l.state}`,
    description: `Coworking, meeting rooms and virtual offices in ${l.name}, compared by price and reviews.`,
    alternates: { canonical: url(`/cities/${l.slug}`) },
  };
}

/** City hub: every category available in one city. */
export default async function City({ params }: Params) {
  const l = await getLocation((await params).city);
  if (!l) notFound();
  const combos = (await getCombos()).filter((c) => c.location.id === l.id && c.indexable);
  if (!combos.length) notFound();
  return (
    <>
      <nav className="crumbs"><Link href="/">Home</Link> › {l.name}</nav>
      <h1>Workspaces in {l.name}</h1>
      <ul className="links">
        {combos.map((c) => (<li key={c.service.id}><Link href={`/${c.service.slug}/${l.slug}`}>{c.service.plural} in {l.name}</Link><small>{c.count} places</small></li>))}
      </ul>
    </>
  );
}
